﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreIncrease : MonoBehaviour
{
    private ScoreHolder scoreHolderRef;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Treasure")
        {
            scoreHolderRef = GameObject.FindWithTag("SceneController").GetComponent<ScoreHolder>();
            scoreHolderRef.IncreaseScore();
            Destroy(collision.gameObject);
        }
    }

    private void Start()
    {
        Destroy(gameObject, 3.0f);
    }
}
